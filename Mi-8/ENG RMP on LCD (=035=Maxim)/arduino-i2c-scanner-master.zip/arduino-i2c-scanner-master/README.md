arduino-i2c-scanner
===================

Simple Arduino I2C scanner as described at http://todbot.com/blog/2009/11/29/i2cscanner-pde-arduino-as-i2c-bus-scanner/
